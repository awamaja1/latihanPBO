/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mystudiesrpl.pertemuan13;

/**
 *
 * @author PC2021
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrameSearch extends JFrame {
    private JTextField searchField;
    private JButton searchButton;
    private JTextArea resultArea;

    public FrameSearch() {
        // Set judul frame
        setTitle("Search Bar Example");
        
        // Set layout frame
        setLayout(new BorderLayout());
        
        // Buat panel untuk search bar
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout());
        
        // Buat JTextField untuk input pencarian
        searchField = new JTextField(20);
        
        // Buat JButton untuk memicu pencarian
        searchButton = new JButton("Search");
        
        // Tambahkan JTextField dan JButton ke panel
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Tambahkan panel ke bagian atas frame
        add(searchPanel, BorderLayout.NORTH);
        
        // Buat JTextArea untuk menampilkan hasil pencarian
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        
        // Tambahkan JTextArea ke frame dalam JScrollPane
        add(new JScrollPane(resultArea), BorderLayout.CENTER);
        
        // Tambahkan ActionListener ke tombol pencarian
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performSearch();
            }
        });
        
        // Atur ukuran frame dan buat visible
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Method untuk melakukan pencarian
    private void performSearch() {
        String query = searchField.getText();
        
        // Di sini Anda bisa menambahkan logika pencarian
        // Untuk contoh ini, kita hanya menampilkan input pencarian di JTextArea
        resultArea.setText("Search results for: " + query);
        
        // Contoh logika pencarian sederhana (bisa disesuaikan)
        if (query.equalsIgnoreCase("java")) {
            resultArea.append("\n- Java is a popular programming language.");
        } else if (query.equalsIgnoreCase("swing")) {
            resultArea.append("\n- Swing is a GUI toolkit for Java.");
        } else {
            resultArea.append("\n- No results found.");
        }
    }

    public static void main(String[] args) {
        // Jalankan aplikasi
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FrameSearch();
            }
        });
    }
}

