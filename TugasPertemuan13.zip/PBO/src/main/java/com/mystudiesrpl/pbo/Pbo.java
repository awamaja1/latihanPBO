/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mystudiesrpl.pbo;
import com.mystudiesrpl.pertemuan13.FrameLogin;
import java.sql.SQLException;

/**
 *
 * @author PC2021
 */
public class Pbo {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
         FrameLogin login =  new FrameLogin();
         login.setVisible(true);
    }
    
}
